-- 選用：demo 貓咪資料，方便部署後馬上有東西可以看。
-- 志工帳號請部署後用「管理員」登入（密碼放在 Cloudflare 的 ADMIN_PASSWORD 環境變數）
-- 到「志工管理」頁面新增，密碼會在伺服器端正確雜湊，不建議直接寫在 SQL 裡。

with c1 as (
  insert into cats (name, gender, age, color, personality_tags, foster_date, rescue_source, status,
    health_external, health_vaccine, health_neuter, health_chip, health_status, adoption_status)
  values ('月亮','女生','6個月～1歲','三花', array['慢熟','親人','溫和'], '2026-07-02','路邊拾獲','找家中',
    '已完成','已完成第一劑','未完成','未完成','健康良好','找家中')
  returning id
)
insert into adoption_records (cat_id, status_date, status, volunteer_name, note)
select id, '2026-07-05', '找家中', '小雅', '剛結束檢疫，開放認養。' from c1;

with c2 as (
  insert into cats (name, gender, age, color, personality_tags, foster_date, rescue_source, status,
    health_external, health_vaccine, health_neuter, health_chip, health_status, adoption_status)
  values ('酸酸','男生','1～2歲','橘白', array['活潑','好動','喜歡逗貓棒'], '2026-05-18','志工轉介','治療中',
    '已完成','未施打','已完成','已完成','治療中','治療中')
  returning id
)
insert into adoption_records (cat_id, status_date, status, volunteer_name, note)
select id, '2026-06-01', '治療中', '阿柏', '發現皮膚問題，暫停開放認養。' from c2;

with c3 as (
  insert into cats (name, gender, age, color, personality_tags, foster_date, rescue_source, status,
    health_external, health_vaccine, health_neuter, health_chip, health_status, adoption_status)
  values ('大寶','男生','2～5歲','黑白（乳牛）', array['穩重','親人','喜歡曬太陽'], '2026-03-22','中途轉介','已找到家',
    '已完成','已完成','已完成','已完成','健康良好','已找到家')
  returning id
)
insert into adoption_records (cat_id, status_date, status, volunteer_name, note)
select id, '2026-07-28', '已找到家', '小雅', '完成簽約，順利送養。' from c3;
