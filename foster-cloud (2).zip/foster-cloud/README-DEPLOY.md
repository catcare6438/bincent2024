# 部署指南（Cloudflare Workers + Neon）

您在 Cloudflare 建立的 `bincent2024` 專案，是 Cloudflare 現在（2026）新專案預設的
「**Worker + 靜態檔案**」類型，不是舊版的 Pages。這份指南就是照這個類型寫的，
**不需要重新建立專案**，直接把這份更新後的檔案推上您原本連接的 GitHub repo 即可。

---

## 這次資料夾多了什麼

跟前一版比，這次多了：
- `wrangler.jsonc`：告訴 Cloudflare 這個 Worker 要怎麼跑（哪個檔案是進入點、
  `public/` 資料夾當作靜態網站、`/api/*` 一律先進 Worker 處理）
- `src/index.js`：一支路由程式，負責把 `/api/...` 的請求分配給對應的處理邏輯，
  其他請求（像是打開首頁）就交給 `public/` 裡的網頁
- `src/functions/`：原本的後端邏輯，內容完全沒變，只是搬進 `src/` 底下

`public/`、`schema.sql`、`seed.sql` 跟之前一樣，不用重新處理。

---

## 第一步：Neon 資料庫（如果您上次已經做過這步，可以跳過）

1. 登入 Neon，打開您的專案（`long-glitter-61166395`）。
2. 左側「SQL Editor」，貼上 `schema.sql` 整份內容，執行。
3. （選用）想要一開始有示範資料，再貼 `seed.sql` 執行一次。
4. 在專案首頁找到「Connection string」，複製起來（等一下第 3 步要用，不要貼給任何人）。

---

## 第二步：把新的檔案推上 GitHub

把這次資料夾**整個內容**（包含新的 `wrangler.jsonc`、`src/` 資料夾）上傳到您原本那個
`catcare6438/bincent2024` repo 的最外層，覆蓋掉舊的 `functions/` 資料夾
（如果舊的 `functions/` 資料夾還在 repo 裡，麻煩手動刪除，避免混淆）：

- 網頁操作：打開 repo → **Add file → Upload files** → 把資料夾內容拖進去 → Commit changes。
- 或指令列：
  ```bash
  cd foster-cloud
  git add .
  git commit -m "add worker entry + wrangler config"
  git push
  ```

因為 Cloudflare 現在支援 Worker 的 Git 自動建置（Workers Builds），
只要您的 `bincent2024` 專案原本就是連接這個 repo，push 上去之後
Cloudflare 應該會自動偵測到 `wrangler.jsonc` 並開始建置部署，不需要再手動建立新專案。

---

## 第三步：設定環境變數

1. 回到 Cloudflare Dashboard → **Workers & Pages** → 點進 `bincent2024` 專案。
2. 找 **Settings**，裡面應該有「Variables and Secrets」（或類似字樣）的區塊。
3. 新增以下三筆，型態選 **Secret**（加密儲存）：

   | 變數名稱 | 值 |
   |---|---|
   | `DATABASE_URL` | 第一步複製的 Neon 連線字串 |
   | `AUTH_SECRET` | 一串隨機長字串（可在瀏覽器開發者工具 Console 打 `crypto.randomUUID()+crypto.randomUUID()` 產生） |
   | `ADMIN_PASSWORD` | 您要設定的管理員登入密碼（不要用曾經貼過的舊密碼） |

4. 儲存後，通常需要**重新觸發一次部署**環境變數才會生效
   （可以到 **Deployments** 分頁按最新一筆旁邊的選項重新部署，
   或直接對 GitHub 隨便 push 一個小改動）。

---

## 第四步：啟用網址

您截圖裡顯示「No URLs enabled」，代表目前這個 Worker 還沒有對外網址。處理方式：

1. 到專案裡的 **Settings**（或 **Domains** 分頁），找「Enable workers.dev subdomain」之類的選項，打開它。
2. 打開後，Cloudflare 會給您一個網址，類似 `https://bincent2024.<您的帳號子網域>.workers.dev`。
3. 如果第二、三步都已經生效，打開這個網址應該會看到前台「認養專區」。

---

## 第五步：登入管理員、建立志工帳號

1. 打開網址，右上角「志工登入」→ 切到「管理員登入」→ 輸入 `ADMIN_PASSWORD`。
2. 登入後到「志工管理」，用「＋ 新增志工帳號」幫每位志工建立姓名和密碼。
3. 之後志工登入選「志工登入」，下拉選單選名字即可。

---

## 如果卡住了

把您在 Cloudflare 看到的畫面或錯誤文字（**不含密碼、連線字串**）描述給我，
常見會卡住的地方：
- **Deployments 分頁顯示建置失敗（Failed）**：通常是 `wrangler.jsonc` 或檔案路徑問題，
  把錯誤訊息貼給我最快。
- **打開網址是空白頁或 404**：多半是環境變數設定完沒有重新部署，回到第三步最後一項。
- **打開網址後貓咪列表一直轉圈或顯示錯誤**：多半是 `DATABASE_URL` 貼錯或 Neon 那邊
  `schema.sql` 還沒執行，回到第一步確認。

---

## 這個架構做了什麼（安全性 / 效能）

- **Cloudflare 的邊緣網路 + 自動 DDoS / WAF 防護**：這就是您要的「防護盾」，
  免費方案就內建，不需要額外設定。
- **管理員密碼、資料庫連線字串、簽署 token 的密鑰**：全部只存在 Cloudflare 的
  Secret 環境變數裡，前端網頁程式碼完全看不到。
- **志工密碼**：用 PBKDF2 加鹽雜湊後才存進 Neon，不是明文。
- **前台公開頁面**：只能讀取「可以公開的欄位」，健康病歷細節、志工備註、
  用藥資訊都只有登入後才看得到，這是後端 API 強制擋下來的，不是單純前端藏起來而已。
