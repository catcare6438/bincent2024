-- 浪貓不浪｜中途管理系統 資料庫結構
-- 在 Neon 的 SQL Editor（或任何連上 Neon 的 psql 用戶端）貼上整份執行即可。
-- PostgreSQL 13+ 內建 gen_random_uuid()，不需要額外安裝 extension。

create table if not exists volunteers (
  id            uuid primary key default gen_random_uuid(),
  name          text not null,
  password_hash text not null,
  salt          text not null,
  active        boolean not null default true,
  created_at    timestamptz not null default now()
);

create table if not exists cats (
  id                 uuid primary key default gen_random_uuid(),
  name               text not null,
  gender             text,
  age                text,
  color              text,
  personality_tags   text[] not null default '{}',
  foster_date        date,
  rescue_source      text,
  status             text not null default '找家中',
  health_external    text,
  health_vaccine     text,
  health_neuter      text,
  health_chip        text,
  health_status      text,
  health_note        text,
  adoption_status    text,
  ai_intro           text,
  ai_adoption_text   text,
  ai_generated_at    timestamptz,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);
create index if not exists idx_cats_updated_at on cats(updated_at desc);
create index if not exists idx_cats_status on cats(status);

create table if not exists cat_photos (
  id         uuid primary key default gen_random_uuid(),
  cat_id     uuid not null references cats(id) on delete cascade,
  data_url   text not null,      -- 壓縮後的 base64 JPEG（demo 規模足夠；正式量大建議改存 Cloudflare R2 只存網址）
  is_main    boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists idx_cat_photos_cat_id on cat_photos(cat_id);

create table if not exists health_records (
  id              uuid primary key default gen_random_uuid(),
  cat_id          uuid not null references cats(id) on delete cascade,
  record_date     date not null,
  type            text not null,
  volunteer_name  text not null,
  note            text,
  diseases        jsonb not null default '[]',  -- [{name, needsMed, totalPacks, frequency}]
  created_at      timestamptz not null default now()
);
create index if not exists idx_health_records_cat_id on health_records(cat_id);

create table if not exists medications (
  id               uuid primary key default gen_random_uuid(),
  cat_id           uuid not null references cats(id) on delete cascade,
  disease          text not null,
  total_packs      int not null,
  frequency        text not null,       -- 一天一次 / 早晚一次
  per_day          int not null,
  remaining_packs  int not null,
  volunteer_name   text not null,
  started_at       timestamptz not null default now()
);
create index if not exists idx_medications_cat_id on medications(cat_id);

create table if not exists foster_logs (
  id              uuid primary key default gen_random_uuid(),
  cat_id          uuid not null references cats(id) on delete cascade,
  log_date        date not null,
  content         text not null,
  volunteer_name  text,
  created_at      timestamptz not null default now()
);
create index if not exists idx_foster_logs_cat_id on foster_logs(cat_id);

create table if not exists adoption_records (
  id              uuid primary key default gen_random_uuid(),
  cat_id          uuid not null references cats(id) on delete cascade,
  status_date     date not null,
  status          text not null,
  volunteer_name  text not null,
  note            text,
  created_at      timestamptz not null default now()
);
create index if not exists idx_adoption_records_cat_id on adoption_records(cat_id);

create table if not exists line_posts (
  id              uuid primary key default gen_random_uuid(),
  cat_id          uuid not null references cats(id) on delete cascade,
  content         text not null,
  volunteer_name  text not null,
  sent_at         timestamptz not null default now()
);
create index if not exists idx_line_posts_cat_id on line_posts(cat_id);

create table if not exists ai_generated_contents (
  id             uuid primary key default gen_random_uuid(),
  cat_id         uuid not null references cats(id) on delete cascade,
  intro          text,
  adoption_text  text,
  generated_at   timestamptz not null default now()
);
create index if not exists idx_ai_contents_cat_id on ai_generated_contents(cat_id);

create table if not exists activity_log (
  id        uuid primary key default gen_random_uuid(),
  at        timestamptz not null default now(),
  by_name   text not null,
  role      text,
  action    text not null,
  cat_id    uuid references cats(id) on delete set null,
  cat_name  text,
  detail    text
);
create index if not exists idx_activity_log_at on activity_log(at desc);

create table if not exists system_settings (
  key   text primary key,
  value jsonb
);
